"""Self-contained unit tests: uses ONLY synthetic, internal fixture data."""
import io
import sys
import unittest
import zipfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from server import GTFS, pick_resource, route_journeys

FILES = {
 'stops.txt': '''stop_id,stop_code,stop_name,stop_lat,stop_lon\nS1,AAA1,Paragem A,41.1,-8.6\nS2,BBB1,Paragem B,41.2,-8.6\nS3,CCC1,Paragem C,41.3,-8.6\nS4,DDD1,Paragem D,41.4,-8.6\n''',
 'routes.txt': 'route_id,route_short_name,route_long_name\nR1,100,A a C\nR2,200,B a D\n',
 'trips.txt': 'route_id,service_id,trip_id,trip_headsign,direction_id\nR1,W,T1,C,0\nR2,W,T2,D,0\n',
 'stop_times.txt': 'trip_id,arrival_time,departure_time,stop_id,stop_sequence\nT1,12:00:00,12:00:00,S1,1\nT1,12:10:00,12:10:00,S2,2\nT1,12:20:00,12:20:00,S3,3\nT2,13:00:00,13:00:00,S2,1\nT2,13:10:00,13:10:00,S4,2\n',
 'calendar.txt':'service_id,monday,tuesday,wednesday,thursday,friday,saturday,sunday,start_date,end_date\nW,1,1,1,1,1,0,0,20260101,20261231\n',
 'calendar_dates.txt':'service_id,date,exception_type\nW,20261012,2\n'
}
def mkgtfs():
    b=io.BytesIO()
    with zipfile.ZipFile(b,'w') as z:
        for n,v in FILES.items():z.writestr(n,v)
    return b.getvalue()

class TestSTCP(unittest.TestCase):
    def setUp(self):self.db=GTFS(mkgtfs())
    def test_load(self):
        self.assertEqual(len(self.db.stops),4)
        self.assertEqual(len(self.db.routes),2)
        self.assertEqual(self.db.stops['S1']['code'],'AAA1')
    def test_exception_overrides_weekday(self):
        self.assertFalse(self.db.service_active('W',datetime(2026,10,12).date()))
        self.assertTrue(self.db.service_active('W',datetime(2026,10,13).date()))
    def test_schedule(self):
        out=self.db.arrivals('S1',now=datetime(2026,10,13,11,50,tzinfo=ZoneInfo('Europe/Lisbon')))
        self.assertEqual(out[0]['minutes'],10)
        self.assertEqual(out[0]['kind'],'scheduled')
    def test_routes(self):
        direct=route_journeys(self.db,'S1','S3')
        self.assertEqual(direct[0]['transfers'],0)
        transfer=route_journeys(self.db,'S1','S4')
        self.assertEqual(transfer[0]['transfers'],1)
        self.assertEqual(transfer[0]['via']['id'],'S2')
    def test_pick_newest(self):
        candidates=[{'name':'GTFS STCP 07-09-2026','format':'ZIP','url':'https://example.com/1.zip'},
                    {'name':'GTFS STCP 24-09-2026 Mais Recente','format':'ZIP','url':'https://example.com/2.zip'}]
        self.assertIn('2.zip',pick_resource(candidates)['url'])

if __name__=='__main__':unittest.main()
